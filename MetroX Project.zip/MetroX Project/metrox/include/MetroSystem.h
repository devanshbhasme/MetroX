#pragma once

#include <map>
#include <memory>
#include <string>
#include <vector>

#include "Station.h"
#include "Train.h"
#include "Passenger.h"
#include "StudentPassenger.h"
#include "SeniorPassenger.h"
#include "Ticket.h"
#include "Route.h"
#include "Payment.h"

/**
 * @class MetroSystem
 * @brief Central controller managing stations, trains, passengers, tickets, and fare logic.
 * Demonstrates: Controller Pattern, Polymorphism with std::unique_ptr, Invariant Validation, Safe Input Handling.
 */
class MetroSystem {
private:
    std::map<int, Station> stations;
    std::map<int, Train> trains;
    std::map<int, std::unique_ptr<Passenger>> passengers;
    std::map<int, Ticket> tickets;

    // Auto-increment unique ID generators
    int nextStationId;
    int nextTrainId;
    int nextPassengerId;
    int nextTicketId;

    // Configurable fare parameters
    double baseFare;      // Flat minimum base fare (e.g. ₹10.00)
    double ratePerKm;     // Configurable per-km fare rate (e.g. ₹3.50/km)

    // Data directory path
    std::string dataDirectory;

public:
    MetroSystem();
    ~MetroSystem() = default;

    // Initial setup and sample seed
    void seedSampleData();

    // Menu Action Handlers (Options 1 - 18)
    void addStationMenu();
    void displayAllStations() const;
    void connectStationsMenu();
    void addTrainMenu();
    void displayTrainsAndStatus() const;
    void registerNormalPassengerMenu();
    void registerStudentPassengerMenu();
    void registerSeniorPassengerMenu();
    void displayAllPassengers() const;
    void findRouteBFSMenu() const;
    void findShortestRouteDijkstraMenu() const;
    void bookTicketMenu();
    void cancelTicketMenu();
    void displayAllTickets() const;
    void simulateStandalonePaymentMenu();
    void displayTrainCapacity() const;
    void saveDataMenu();
    void loadDataMenu();

    // Fare calculation
    double calculateFare(double distance, double discountFraction) const;

    // Safe input utility functions
    static int readInt(const std::string& prompt, int minVal = -2147483647, int maxVal = 2147483647);
    static double readDouble(const std::string& prompt, double minVal = 0.0, double maxVal = 1e9);
    static std::string readString(const std::string& prompt);
    static std::string readLine(const std::string& prompt);
    static void clearInputBuffer();
};
